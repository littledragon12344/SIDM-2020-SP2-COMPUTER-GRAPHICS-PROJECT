#ifndef TP_CAMERA_H
#define TP_CAMERA_H

#include "BaseCamera.h"
#include "Wall.h"

class TPCamera : public BaseCamera
{
public:
	//Vector3 position;
	//Vector3 target;
	//Vector3 up;
	Vector3 TargetFromPos;
	Vector3 xzTarget;
	Vector3 xzPosition;

	TPCamera();
	~TPCamera();
	virtual void Init(const Vector3& pos, const Vector3& target, const Vector3& up);
	virtual void Update(double dt);
	virtual void Reset();
};

#endif