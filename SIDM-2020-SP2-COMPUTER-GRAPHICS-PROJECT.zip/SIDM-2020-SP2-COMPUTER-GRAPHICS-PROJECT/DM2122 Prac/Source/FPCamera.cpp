#include "FPCamera.h"
#include "Application.h"
#include "Mtx44.h"
#include "Utility.h"
#include "Wall.h"

FPCamera::FPCamera()
{
}

FPCamera::~FPCamera()
{
}

void FPCamera::Init(const Vector3& pos, const Vector3& target, const Vector3& up)
{
	this->position = defaultPosition = pos;
	this->target = defaultTarget = target;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	this->up = defaultUp = right.Cross(view).Normalized();
}

void FPCamera::Update(double dt)
{
	static const float CAMERA_SPEED = 50.f;

	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up).Normalized();
	Vector3 posDisplacement = Vector3(0, 0, 0);

	if (Application::IsKeyPressed('W'))
		posDisplacement += view;
	if (Application::IsKeyPressed('S'))
		posDisplacement -= view;
	if (Application::IsKeyPressed('A'))
		posDisplacement -= right;
	if (Application::IsKeyPressed('D'))
		posDisplacement += right;

	// Updating camera's position 
	// Only update when posDisplacement changed
	if (posDisplacement != Vector3(0, 0, 0))
	{
		posDisplacement.y = 0;

		posDisplacement = posDisplacement.Normalized() * (float)(CAMERA_SPEED * dt);
		Vector3 displacementAftCollide = Wall::dispAftCollideWithWall(position, posDisplacement);

		position += displacementAftCollide;
		target = position + view;
	}

	if (Application::IsKeyPressed(VK_LEFT))
	{
		// Yaw view vector leftward
		float yaw = (float)(CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(yaw, 0, 1, 0);
		view = rotation * view;
		target = position + view.Normalize();
		up = rotation * up;
	}
	if (Application::IsKeyPressed(VK_RIGHT))
	{
		// Yaw view vector rightward
		float yaw = (float)(-CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(yaw, 0, 1, 0);
		view = (rotation * view).Normalized();
		target = position + view;
		up = rotation * up;
	}
	if (Application::IsKeyPressed(VK_UP))
	{
		if (up.y < 0.1 && view.y > 0)
			return;

		// Pitch view vector upwards
		float pitch = (float)(CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(pitch, right.x, right.y, right.z);
		view = rotation * view;
		target = position + view.Normalized();
		up = (rotation * up).Normalized();
	}
	if (Application::IsKeyPressed(VK_DOWN))
	{
		if (up.y < 0.1 && view.y < 0)
			return;

		// Pitch view vector downwards
		float pitch = (float)(-CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(pitch, right.x, right.y, right.z);
		view = rotation * view;
		target = position + view.Normalized();
		up = (rotation * up).Normalized();
	}
	if (Application::IsKeyPressed('R'))
		Reset();
}

void FPCamera::Reset()
{
	position = defaultPosition;
	target = defaultTarget;
	up = defaultUp;
}