#ifndef FREE_CAMERA_H
#define FREE_CAMERA_H

#include "BaseCamera.h"

class FreeCamera : public BaseCamera
{
public:
	//Vector3 position;
	//Vector3 target;
	//Vector3 up;
	Vector3 TargetFromPos;
	Vector3 xzTarget;
	Vector3 xzPosition;

	Vector3 defaultPosition;
	Vector3 defaultTarget;
	Vector3 defaultUp;

	FreeCamera();
	~FreeCamera();
	virtual void Init(const Vector3& pos, const Vector3& target, const Vector3& up);
	virtual void Reset();
	virtual void Update(double dt);
};

#endif