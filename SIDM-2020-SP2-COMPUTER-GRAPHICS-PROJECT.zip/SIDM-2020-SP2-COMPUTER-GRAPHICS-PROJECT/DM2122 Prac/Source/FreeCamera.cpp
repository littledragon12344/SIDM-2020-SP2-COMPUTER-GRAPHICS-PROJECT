#include "FreeCamera.h"
#include "Application.h"
#include "Mtx44.h"
#include "Utility.h"
#include "Wall.h"

FreeCamera::FreeCamera()
{
}

FreeCamera::~FreeCamera()
{
}

void FreeCamera::Init(const Vector3& pos, const Vector3& target, const Vector3& up)
{
	this->position = defaultPosition = pos;
	this->target = defaultTarget = target;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	this->up = defaultUp = right.Cross(view).Normalized();
}

void FreeCamera::Update(double dt)
{
	static const float CAMERA_SPEED = 50.f;

	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up).Normalized();
	Vector3 posDisplacement = Vector3(0, 0, 0);

	if (Application::IsKeyPressed('W'))
	{
		position += view * (float)(CAMERA_SPEED * dt);
		target = position + view;
	}
	if (Application::IsKeyPressed('S'))
	{
		posDisplacement -= view * (float)(CAMERA_SPEED * dt);
		target = position + view;
	}
	if (Application::IsKeyPressed('A'))
	{
		posDisplacement -= right * (float)(CAMERA_SPEED * dt);
		target = position + view;
	}
	if (Application::IsKeyPressed('D'))
	{
		posDisplacement += right * (float)(CAMERA_SPEED * dt);
		target = position + view;
	}

	if (Application::IsKeyPressed(VK_LEFT))
	{
		// Yaw view vector leftward
		float yaw = (float)(CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(yaw, 0, 1, 0);
		view = rotation * view;
		target = position + view.Normalize();
		up = rotation * up;
	}
	if (Application::IsKeyPressed(VK_RIGHT))
	{
		// Yaw view vector rightward
		float yaw = (float)(-CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(yaw, 0, 1, 0);
		view = (rotation * view).Normalized();
		target = position + view;
		up = rotation * up;
	}
	if (Application::IsKeyPressed(VK_UP))
	{
		if (up.y < 0.1 && view.y > 0)
			return;

		// Pitch view vector upwards
		float pitch = (float)(CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(pitch, right.x, right.y, right.z);
		view = rotation * view;
		target = position + view.Normalized();
		up = (rotation * up).Normalized();
	}
	if (Application::IsKeyPressed(VK_DOWN))
	{
		if (up.y < 0.1 && view.y < 0)
			return;

		// Pitch view vector downwards
		float pitch = (float)(-CAMERA_SPEED * dt);
		Mtx44 rotation;
		rotation.SetToRotation(pitch, right.x, right.y, right.z);
		view = rotation * view;
		target = position + view.Normalized();
		up = (rotation * up).Normalized();
	}
}

void FreeCamera::Reset()
{
	position = defaultPosition;
	target = defaultTarget;
	up = defaultUp;
}