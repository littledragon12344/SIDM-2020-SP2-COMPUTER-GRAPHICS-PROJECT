#ifndef CAMERA_H
#define CAMERA_H

#include "Vector3.h"

class BaseCamera
{
public:
	Vector3 position;
	Vector3 target;
	Vector3 up;

	Vector3 defaultPosition;
	Vector3 defaultTarget;
	Vector3 defaultUp;

	virtual void Init(const Vector3& pos, const Vector3& target, const Vector3& up) = 0;
	virtual void Reset() = 0;
	virtual void Update(double dt) = 0;
};

#endif