#ifndef FP_CAMERA_H
#define FP_CAMERA_H

#include "BaseCamera.h"

class FPCamera : public BaseCamera
{
public:
	//Vector3 position;
	//Vector3 target;
	//Vector3 up;

	FPCamera();
	~FPCamera();
	virtual void Init(const Vector3& pos, const Vector3& target, const Vector3& up);
	virtual void Update(double dt);
	virtual void Reset();
};

#endif